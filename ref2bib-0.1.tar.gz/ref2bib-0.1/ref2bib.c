/*
 * ref2bib - convert refer databases to bibtex files
 *
 * Copyright (C) 2012-2014 Ali Gholami Rudi <ali at rudi dot ir>
 *
 * This program is released under the Modified BSD license.
 */
#include <ctype.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define BUFSZ		(1 << 20)
#define NREFS		(1 << 10)

struct ref {
	char *keys[128];	/* reference keys */
	char *auth[128];	/* authors */
	int nauth;
};

static struct ref refs[NREFS];	/* all references in refer db */
static int nrefs;

#define ref_label(ref)		((ref)->keys['L'])

static int xread(int fd, char *buf, int len)
{
	int nr = 0;
	while (nr < len) {
		int ret = read(fd, buf + nr, len - nr);
		if (ret <= 0)
			break;
		nr += ret;
	}
	return nr;
}

/* read a single refer record */
static char *db_ref(char *s, struct ref *ref)
{
	char *end;
	while (*s != '\n') {
		end = strchr(s, '\n');
		if (!end)
			return strchr(s, '\0');
		*end = '\0';
		if (s[0] == '%' && s[1] >= 'A' && s[1] <= 'Z') {
			char *r = s + 2;
			while (isspace(*r))
				r++;
			if (s[1] == 'A')
				ref->auth[ref->nauth++] = r;
			else
				ref->keys[(unsigned) s[1]] = r;
		}
		s = end + 1;
		while (*s == ' ' || *s == '\t')
			s++;
	}
	return s;
}

/* parse a refer-style bib file and fill refs[] */
static int db_parse(char *s)
{
	while (*s) {
		while (isspace(*s))
			s++;
		s = db_ref(s, &refs[nrefs++]);
	}
	return 0;
}

static char *names[128] = {
	['A'] = "author",
	['B'] = "booktitle",
	['C'] = "address",
	['D'] = "year",
	['I'] = "publisher",
	['J'] = "journal",
	['K'] = "keywords",
	['N'] = "number",
	['O'] = "note",
	['P'] = "pages",
	['T'] = "title",
	['V'] = "volume",
};

/* print all references */
static int bibtex(struct ref *r)
{
	int i;
	char *type = "article";
	if (!r->keys['L'])
		return 1;
	if (!r->keys['J'])
		type = "book";
	if (r->keys['B'])
		type = "conference";
	printf("@%s{%s,\n", type, r->keys['L']);
	if (r->nauth) {
		printf("\tauthor = \"");
		for (i = 0; i < r->nauth; i++) {
			if (i > 0)
				printf(" and ");
			printf("%s", r->auth[i]);
		}
		printf("\",\n");
	}
	for (i = 'A'; i <= 'Z'; i++)
		if (r->keys[i] && names[i])
			printf("\t%s = \"%s\",\n", names[i], r->keys[i]);
	printf("}\n");
	return 0;
}

static char bib[BUFSZ];

int main(int argc, char *argv[])
{
	int i;
	if (argc > 1) {
		printf("Usage: ref2bib <bib.refer >bib.bibtex\n");
		return 1;
	}
	xread(0, bib, sizeof(bib) - 1);
	db_parse(bib);
	for (i = 0; i < nrefs; i++)
		bibtex(&refs[i]);
	return 0;
}
