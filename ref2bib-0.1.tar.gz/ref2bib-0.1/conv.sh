# !/bin/sh

# after ref2bib, one usually needs to fix things like:
./ref2bib | sed 's/\\-/--/; s/&/\\&/'
