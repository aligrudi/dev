/*
 * a simple socks server
 *
 * Copyright (C) 2010-2011 Ali Gholami Rudi
 *
 * This file is released under GNU GPL version 2.
 */
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define MAXCONNS		16
#define MAXFDS			(MAXCONNS * 2 + 1)

#define CONN_CLOSED		0
#define CONN_NEW		1
#define CONN_GREETED		2
#define CONN_CONNECTED		3

static int net_connect(uint32_t ip, uint16_t port, int tcp)
{
	struct sockaddr_in addr;
	int fd = socket(AF_INET, tcp ? SOCK_STREAM : SOCK_DGRAM, 0);
	if (fd == -1)
		return -1;
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ip;
	addr.sin_port = port;
	if (connect(fd, (void *) &addr, sizeof(addr)) == -1 && errno != EINPROGRESS) {
		close(fd);
		return -1;
	}
	return fd;
}

static int net_bind(int port)
{
	struct sockaddr_in addr;
	int yes = 1;
	int fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd == -1)
		return -1;
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
	if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) < 0)
		return -1;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(port);
	if (bind(fd, (void *) &addr, sizeof(addr)) < 0)
		return -1;
	if (listen(fd, 10) < 0)
		return -1;
	return fd;
}

struct conn {
	int fd1;
	int fd2;
	int step;
};
static struct conn conns[MAXCONNS];

static int conn_new(int sfd)
{
	int fd = accept(sfd, NULL, NULL);
	struct conn *conn;
	int i;
	if (fd == -1)
		return -1;
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
	for (i = 0; !conn && i < MAXCONNS; i++)
		if (conns[i].step == CONN_CLOSED)
			conn = &conns[i];
	if (!conn) {
		close(fd);
		return -1;
	}
	conn->fd1 = fd;
	conn->step = CONN_NEW;
	return 0;
}

static uint32_t lookup(char *name)
{
	struct hostent *he = gethostbyname(name);
	return he ? *(uint32_t *) he->h_addr_list[0] : 0;
}

static int conn_greet(struct conn *conn)
{
	unsigned char req[128];
	unsigned char res[] = "\05\00";
	int len = read(conn->fd1, req, sizeof(req));
	if (len == -1 || req[0] != 5 || req[1] > len - 2)
		goto failed;
	if (write(conn->fd1, res, 2) != 2)
		goto failed;
	conn->step = CONN_GREETED;
	return 0;
failed:
	conn->step = CONN_CLOSED;
	close(conn->fd1);
	return -1;
}

static int conn_connect(struct conn *conn)
{
	unsigned char req[128];
	uint32_t ip = 0;
	uint16_t port = 0;
	int len = read(conn->fd1, req, sizeof(req));
	int cmd = req[1];
	int type = req[3];
	int fd = -1;
	if (len < 8 || req[0] != 5 || req[2] != 0)
		goto failed;
	if (cmd != 1 && cmd != 3 || type != 1 && type != 3)
		goto failed;
	if (type == 1) {
		ip = *(uint32_t *) (req + 4);
		port = *(uint16_t *) (req + 8);
	}
	if (type == 3) {
		int nlen = req[4];
		char name[128];
		if (4 + nlen + 2 > len)
			goto failed;
		memcpy(name, req + 5, nlen);
		name[nlen] = '\0';
		ip = lookup(name);
		port = *(uint16_t *) (req + 5 + nlen);
	}
	if (ip && port)
		fd = net_connect(ip, port, cmd == 1);
	req[1] = fd > 0 ? 0 : 1;
	write(conn->fd1, req, len);
	if (fd < 0)
		goto failed;
	conn->step = CONN_CONNECTED;
	conn->fd2 = fd;
	return 0;
failed:
	conn->step = CONN_CLOSED;
	close(conn->fd1);
	return -1;
}

static int transfer(int fd1, int fd2)
{
	char buf[2048];
	while (1) {
		int tx = 0;
		int rx = read(fd1, buf, sizeof(buf));
		if (rx == -1 && (errno == EAGAIN || errno == EINTR))
			return 0;
		if (rx <= 0)
			return -1;
		while (tx < rx) {
			int ret = write(fd2, buf + tx, rx - tx);
			if (rx == -1 && errno != EAGAIN && errno != EINTR)
				return -1;
			if (ret > 0)
				tx += ret;
			else
				usleep(10000);
		}
	}
	return 0;
}

static int conn_data(struct conn *conn, int fd)
{
	int ret;
	if (conn->fd1 == fd)
		ret = transfer(conn->fd1, conn->fd2);
	else
		ret = transfer(conn->fd2, conn->fd1);
	if (ret < 0) {
		close(conn->fd1);
		close(conn->fd2);
		conn->step = CONN_CLOSED;
	}
	return 0;
}

static void loop(int fd)
{
	struct pollfd fds[MAXFDS];
	struct conn *ptr[MAXFDS];
	int nfds = 1;
	int i;
	fds[0].fd = fd;
	fds[0].events = POLLIN | POLLERR;
	while (poll(fds, nfds, 10000) >= 0) {
		if (fds[0].revents & POLLERR)
			break;
		if (fds[0].revents & POLLIN)
			conn_new(fd);
		for (i = 1; i < nfds; i++)
			if (fds[i].revents & (POLLERR | POLLIN)) {
				switch (ptr[i]->step) {
				case CONN_NEW:
					conn_greet(ptr[i]);
					break;
				case CONN_GREETED:
					conn_connect(ptr[i]);
					break;
				case CONN_CONNECTED:
					conn_data(ptr[i], fds[i].fd);
					break;
				}
			}
		nfds = 1;
		for (i = 0; i < MAXCONNS; i++) {
			if (conns[i].step != CONN_CLOSED) {
				fds[nfds].fd = conns[i].fd1;
				ptr[nfds] = &conns[i];
				nfds++;
			}
			if (conns[i].step == CONN_CONNECTED) {
				fds[nfds].fd = conns[i].fd2;
				ptr[nfds] = &conns[i];
				nfds++;
			}
		}
		for (i = 0; i < nfds; i++)
			fds[i].events = POLLIN | POLLERR;
	}
}

int main(int argc, char *argv[])
{
	int fd;
	if (argc > 1 && !isdigit(argv[1][0])) {
		printf("usage:    socks [port/1080]\n");
		return 0;
	}
	fd = net_bind(argc > 1 ? atoi(argv[1]) : 1080);
	if (fd >= 0)
		loop(fd);
	close(fd);
	return 0;
}
