/*
 * bib2ref - create refer databases from bibtex files
 *
 * Copyright (C) 2012-2014 Ali Gholami Rudi <ali at rudi dot ir>
 *
 * This program is released under the Modified BSD license.
 */
#include <ctype.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#define FLEN		512
#define NKEYS		128

/* the next input character */
static int next(void)
{
	return getc(stdin);
}

/* push back the last character */
static void back(int c)
{
	if (c > 0)
		ungetc(c, stdin);
}

/* return nonzero when EOF is reached */
static int iseof(void)
{
	int c = next();
	back(c);
	return c < 0;
}

/* skip space characters */
static int jmpspc(void)
{
	int c = next();
	while (isspace(c))
		c = next();
	back(c);
	return c;
}

/* skip the next character if it is c */
static int jmpchar(int c)
{
	if (jmpspc() != c)
		return 1;
	next();
	return 0;
}

/* read the next word into d */
static int jmpword(char *d)
{
	int c;
	jmpspc();
	c = next();
	while (c >= 0 && !strchr(" \t={},", c)) {
		*d++ = c;
		c = next();
	}
	back(c);
	*d = '\0';
	return 0;
}

/* read a bibtex tag value into d */
static int jmpval(int end, char *d)
{
	int c = next();
	int nested = 0;
	while (c >= 0 && (nested || c != end)) {
		*d++ = c;
		if (c == '{')
			nested++;
		if (c == '}')
			nested--;
		if (c == '\\')
			*d++ = next();
		c = next();
	}
	*d = '\0';
	return 0;
}

/* read a bibtex entry */
static int refread(char *label, char keys[][FLEN], char vals[][FLEN])
{
	int n = 0;
	char type[FLEN];
	if (jmpchar('@'))
		return -1;
	if (jmpword(type))
		return -1;
	if (jmpchar('{'))
		return -1;
	if (jmpword(label))
		return -1;
	if (jmpchar(','))
		return -1;
	while (!iseof()) {
		if (jmpword(keys[n]))
			break;
		if (jmpchar('='))
			break;
		if (!jmpchar('{'))
			jmpval('}', vals[n]);
		if (!jmpchar('"'))
			jmpval('"', vals[n]);
		n++;
		if (jmpchar(','))
			break;
	}
	jmpchar('}');
	return n;
}

/* the mapping from bibtex tags into refer fields */
static struct b2r {
	char *hdr;
	int dst;
} b2r[] = {
	{"address", 'C'},
	{"author", 'A'},
	{"booktitle", 'B'},
	{"city", 'C'},
	{"journal", 'J'},
	{"keywords", 'K'},
	{"note", 'O'},
	{"number", 'N'},
	{"organization", 'I'},
	{"pages", 'P'},
	{"publisher", 'I'},
	{"title", 'T'},
	{"url", 'O'},
	{"volume", 'V'},
	{"year", 'D'},
	{NULL, 0}
};

/* remove beginning, ending, and double blanks; return a static buffer */
static char *trimmed(char *s)
{
	static char out[FLEN];
	char *d = out;
	int spc = 1;
	while (*s) {
		if (!spc || !isspace(*s))
			*d++ = *s;
		spc = isspace(*s++);
	}
	while (d > out && isspace(d[-1]))
		d--;
	*d = '\0';
	return out;
}

/* parse "Aaa, A. and Bbb, B." and output %A for each author */
static void refauthors(char *s)
{
	char out[FLEN];
	char *e, *c, *d;
	while (*s) {
		e = strstr(s, " and ");
		d = out;
		if (!e)
			e = strchr(s, '\0');
		c = memchr(s, ',', e - s);
		if (c) {
			char *m = c + 1;
			while (m < e && isspace(*m))
				m++;
			memcpy(d, m, e - m);
			d += e - m;
			*d++ = ' ';
		} else {
			c = e;
		}
		memcpy(d, s, c - s);
		d += c - s;
		*d = '\0';
		printf("%%A  %s\n", out);
		if (!*e)
			break;
		s = e + 5;
		while (isspace(*s))
			s++;
	}
}

/* return the lower-case string in a static buffer */
static char *lowered(char *s)
{
	static char out[FLEN];
	char *d = out;
	while (*s)
		*d++ = tolower(*s++);
	*d = '\0';
	return out;
}

/* output a refer entry */
static void refput(char *label, char keys[][FLEN], char vals[][FLEN], int n)
{
	int i, j;
	printf("%%L  %s\n", label);
	for (i = 0; i < n; i++) {
		char *key = lowered(keys[i]);
		char *val = trimmed(vals[i]);
		if (!*val)
			continue;
		if (!strcmp("author", key)) {
			refauthors(val);
			continue;
		}
		for (j = 0; b2r[j].hdr; j++)
			if (!strcmp(b2r[j].hdr, key))
				printf("%%%c  %s\n", b2r[j].dst, val);
	}
	printf("\n");
}

int main(int argc, char *argv[])
{
	char label[FLEN];
	char keys[NKEYS][FLEN];
	char vals[NKEYS][FLEN];
	int n;
	if (argc > 1) {
		printf("Usage: bib2ref <bib.bibtex >bib.refer\n");
		return 1;
	}
	while ((n = refread(label, keys, vals)) >= 0)
		refput(label, keys, vals, n);
	return 0;
}
