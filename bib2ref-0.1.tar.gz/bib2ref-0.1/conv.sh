# !/bin/sh

# after bib2ref, one usually needs to fix things like:
./bib2ref | sed 's/--/\\-/; s/\\&/&/'
