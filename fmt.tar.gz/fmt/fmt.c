/*
 * a small utf-8 unix fmt clone
 *
 * Copyright (C) 2012-2013 Ali Gholami Rudi <ali at rudi dot ir>
 *
 * This program is released under the modified BSD license.
 */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE		(4096)
#define LIM		(LINE / 2)

static int utf8len(int c)
{
	if (c <= 0x7f)
		return 1;
	if (c >= 0xfc)
		return 6;
	if (c >= 0xf8)
		return 5;
	if (c >= 0xf0)
		return 4;
	if (c >= 0xe0)
		return 3;
	if (c >= 0xc0)
		return 2;
	return 1;
}

static int readword(char *d, char *e)
{
	int w = 0;
	int i;
	while (d + 7 < e) {
		int c = getchar();
		int l = utf8len(c);
		if (c == EOF || isspace(c)) {
			ungetc(c, stdin);
			break;
		}
		*d++ = c;
		for (i = 1; i < l; i++)
			*d++ = getchar();
		w++;
	}
	*d = '\0';
	return w;
}

static void fmt(int wid)
{
	char word[LINE];
	int c;
	int nl;		/* number of newlines before current word */
	int sp;		/* number of spaces before current word */
	int eow = 0;	/* end of previous word type: 0=\n 1=normal 2=.!? */
	int ww;		/* word width */
	int w = 0;	/* line width */
	int i;
	c = getchar();
	while (c != EOF) {
		if (!eow && c == '\n') {
			printf("\n");
			c = getchar();
			continue;
		}
		nl = 0;
		sp = 0;
		while (isspace(c)) {
			if (c == '\n')
				nl++;
			else
				sp++;
			c = getchar();
		}
		if (nl > 1) {
			for (i = 0; i < nl; i++)
				printf("\n");
			eow = 0;
			sp = 0;
			w = 0;
			continue;
		}
		if (c == EOF)
			break;
		ungetc(c, stdin);
		ww = readword(word, word + sizeof(word));
		if (eow == 2)
			sp = sp != 1 ? 2 : 1;
		else
			sp = eow;
		if (w + ww + sp > wid) {
			if (sp)
				printf("\n");
			printf("%s", word);
			w = ww;
		} else {
			w += ww + sp;
			for (i = 0; i < sp; i++)
				printf(" ");
			printf("%s", word);
		}
		eow = strchr(".!?", strchr(word, '\0')[-1]) ? 2 : 1;
		c = getchar();
	}
	if (eow)
		printf("\n");
}

int main(int argc, char *argv[])
{
	int i;
	int wid = 70;
	for (i = 1; i < argc; i++)
		if (argv[i][0] == '-' && argv[i][1] == 'w')
			wid = atoi(argv[i][2] ? argv[i] + 2 : argv[++i]);
	if (wid > LIM)
		wid = LIM;
	fmt(wid);
	return 0;
}
