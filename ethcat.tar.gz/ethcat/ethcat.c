/*
 * a simple ethernet capture/replay tool
 *
 * Copyright (C) 2010-2011 Ali Gholami Rudi
 *
 * This file is released under GNU GPL version 2.
 */
#include <arpa/inet.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <linux/if_ether.h>
#include <linux/if.h>
#include <linux/if_packet.h>

/* pcap file handling */

struct pcapfile {
	uint32_t magic;
	uint16_t vermaj;
	uint16_t vermin;
	uint32_t zone;
	uint32_t sigfigs;
	uint32_t snaplen;
	uint32_t network;
};

struct pcaphdr {
	uint32_t ts_sec;
	uint32_t ts_usec;
	uint32_t incl_len;
	uint32_t orig_len;
};

static int pcap_hdr_get(int fd)
{
	struct pcapfile pcapfile;
	return read(fd, &pcapfile, sizeof(pcapfile));
}

static int pcap_get(int fd, char *buf, int len)
{
	struct pcaphdr pcap;
	if (read(fd, &pcap, sizeof(pcap)) <= 0)
		return -1;
	if (read(fd, buf, pcap.incl_len) <= 0)
		return -1;
	return pcap.incl_len;
}

static int pcap_hdr_put(int fd)
{
	struct pcapfile pcapfile = {0};
	pcapfile.magic = 0xa1b2c3d4;
	pcapfile.vermaj = 2;
	pcapfile.vermin = 4;
	pcapfile.snaplen = 65535;
	pcapfile.network = 1;
	return write(fd, &pcapfile, sizeof(pcapfile));
}

static int pcap_put(int fd, char *buf, int len)
{
	struct pcaphdr pcaphdr = {0};
	struct timeval tv;
	int nw = 0;
	pcaphdr.incl_len = len;
	pcaphdr.orig_len = len;
	if (!gettimeofday(&tv, NULL)) {
		pcaphdr.ts_sec = tv.tv_sec;
		pcaphdr.ts_usec = tv.tv_usec;
	}
	nw += write(fd, &pcaphdr, sizeof(pcaphdr));
	nw += write(fd, buf, len);
	return nw;
}

/* raw socket handling */

static void xerror(char *msg)
{
	perror(msg);
	exit(1);
}

static int get_iface_index(int fd, char *dev)
{
	struct ifreq ifr;
	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, dev);
	if (ioctl(fd, SIOCGIFINDEX, &ifr) == -1)
		xerror("get IFINDEX");
	return ifr.ifr_ifindex;
}              

static int eth_open(char *dev)
{
	int fd;
	struct sockaddr_ll sa;
	if ((fd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0)
		xerror("socket");
	if ((sa.sll_ifindex = get_iface_index(fd, dev)) < 0)
		xerror("socket hw index");
	/* bind socket to our interface id */
	sa.sll_family = AF_PACKET;
	sa.sll_protocol = htons(ETH_P_ALL);
	if (bind(fd, (struct sockaddr *) &sa, sizeof(sa)) < 0)
		xerror("bind");
	return fd;
}

static int eth_send(int fd, char *pkt, int len)
{
	return send(fd, pkt, len, 0);
}

static int eth_recv(int fd, char *pkt, int len)
{
	return recv(fd, pkt, len, 0);
}

int main(int argc, char *argv[])
{
	char buf[2048];
	int len;
	int fd;
	if (argc != 3 || (strcmp("-i", argv[1]) && strcmp("-o", argv[1]))) {
		printf("usage: ethcat [-i eth0] >out.pcap\n");
		printf("usage: ethcat [-o eth0] <out.pcap\n");
		return 1;
	}
	fd = eth_open(argv[2]);
	if (fd < 0)
		return 1;
	if (!strcmp("-i", argv[1])) {
		pcap_hdr_put(1);
		while ((len = eth_recv(fd, buf, sizeof(buf))) > 0) {
			fprintf(stderr, "len: %d\n", len);
			pcap_put(1, buf, len);
		}
	} else {
		pcap_hdr_get(0);
		while ((len = pcap_get(0, buf, sizeof(buf))) > 0) {
			fprintf(stderr, "len: %d\n", len);
			eth_send(fd, buf, len);
		}
	}
	close(fd);
	return 0;
}
